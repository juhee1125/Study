var A = require('./A');
var B = require('./B');

var template = require('../tpl/A/template');