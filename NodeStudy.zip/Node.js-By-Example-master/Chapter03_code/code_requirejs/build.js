({
    baseUrl: ".",
    paths: {},
    name: "main",
    out: "main-built.js"
})