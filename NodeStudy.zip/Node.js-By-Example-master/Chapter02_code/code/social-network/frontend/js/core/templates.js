var templates = require('../../build/templates.js');
module.exports = {};