#!/usr/bin/env node

console.log('Hello, this is my awesome Node.js module!');