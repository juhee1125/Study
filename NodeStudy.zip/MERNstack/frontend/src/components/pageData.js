export const pageData = [
    {
        name: "Home",
        path: "/Home"
    },
    {
        name: "Create Blog",
        path: "/createblog"
    },
    {
        name: "Profile",
        path: "/profile"
    },
    {
        name: "About Us",
        path: "/about"
    },
    {
        name: "Contact",
        path: "/contact"
    }
]